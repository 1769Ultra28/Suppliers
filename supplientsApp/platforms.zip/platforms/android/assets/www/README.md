These are the templates that contains the view side 

## Issues
